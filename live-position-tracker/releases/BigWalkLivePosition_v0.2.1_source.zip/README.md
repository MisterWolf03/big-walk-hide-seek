# Big Walk Live Position — v0.2.1

This is the hosted-site compatibility update.

## What changed

- Keeps the calibrated live Big Walk Y/X output from v0.2.0.
- Adds `OPTIONS` handling for browser preflight requests.
- Adds CORS and private-network response headers so an HTTPS-hosted map can request the loopback bridge at `127.0.0.1`.
- The server still listens on loopback only; it is not exposed to the internet or LAN.

## Install / update

1. Completely close Big Walk first so Windows releases the old plugin DLL.
2. Run `configure_profile.bat` only if your Thunderstore profile path needs changing.
3. Run `build_and_install.bat`.
4. Launch Big Walk with **Start modded** using that Thunderstore profile.
5. The diagnostic page remains available at `http://127.0.0.1:32145/`.

The hosted map may prompt your browser for permission to access a service on your local / loopback network. Allow it for live location to work.
