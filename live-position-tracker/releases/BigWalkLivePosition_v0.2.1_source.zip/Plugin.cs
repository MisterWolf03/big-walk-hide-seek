using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using BepInEx;
using BepInEx.Logging;
using BepInEx.Unity.IL2CPP;
using UnityEngine;

[BepInPlugin("com.bigwalkhideseek.liveposition", "Big Walk Live Position", "0.2.1")]
public class Plugin : BasePlugin
{
    internal static ManualLogSource Logger;

    public override void Load()
    {
        Logger = Log;
        Logger.LogInfo("Big Walk Live Position 0.2.1 loaded.");
        Logger.LogInfo("Diagnostic page: http://127.0.0.1:32145/");
        AddComponent<LivePositionBridge>();
    }
}

public class LivePositionBridge : MonoBehaviour
{
    private const int Port = 32145;
    private Rigidbody playerRb;
    private float searchTimer;

    private readonly object dataLock = new object();
    private float posX;
    private float posY;
    private float posZ;
    private bool hasPlayer;
    private string objectName = "";

    private TcpListener listener;
    private Thread serverThread;
    private volatile bool serverRunning;

    public void Start()
    {
        StartServer();
        TryFindPlayer();
    }

    public void Update()
    {
        searchTimer -= Time.unscaledDeltaTime;

        if (playerRb == null)
        {
            if (searchTimer <= 0f)
            {
                searchTimer = 1f;
                TryFindPlayer();
            }

            lock (dataLock)
            {
                hasPlayer = false;
            }
            return;
        }

        Vector3 p = playerRb.position;
        lock (dataLock)
        {
            posX = p.x;
            posY = p.y;
            posZ = p.z;
            hasPlayer = true;
            objectName = playerRb.gameObject.name;
        }
    }

    private void TryFindPlayer()
    {
        Rigidbody[] bodies = FindObjectsOfType<Rigidbody>();

        foreach (Rigidbody rb in bodies)
        {
            if (rb != null && rb.gameObject != null &&
                rb.gameObject.name.StartsWith("PlayerCharacter "))
            {
                playerRb = rb;
                Plugin.Logger.LogInfo(
                    $"Live-position player found: '{rb.gameObject.name}'"
                );
                return;
            }
        }
    }

    private void StartServer()
    {
        try
        {
            listener = new TcpListener(IPAddress.Loopback, Port);
            listener.Start();
            serverRunning = true;

            serverThread = new Thread(ServerLoop);
            serverThread.IsBackground = true;
            serverThread.Name = "BigWalkLivePositionServer";
            serverThread.Start();

            Plugin.Logger.LogInfo(
                $"Live-position bridge listening on http://127.0.0.1:{Port}/"
            );
        }
        catch (Exception ex)
        {
            Plugin.Logger.LogError($"Could not start live-position server: {ex}");
        }
    }

    private void ServerLoop()
    {
        while (serverRunning)
        {
            try
            {
                using (TcpClient client = listener.AcceptTcpClient())
                {
                    client.ReceiveTimeout = 1500;
                    client.SendTimeout = 1500;

                    using (NetworkStream stream = client.GetStream())
                    {
                        byte[] requestBuffer = new byte[4096];
                        int count = stream.Read(requestBuffer, 0, requestBuffer.Length);
                        string request = Encoding.ASCII.GetString(requestBuffer, 0, Math.Max(0, count));
                        string firstLine = request.Split('\n')[0].Trim();

                        string method = "GET";
                        string path = "/";
                        string[] parts = firstLine.Split(' ');
                        if (parts.Length >= 1)
                            method = parts[0].Trim().ToUpperInvariant();
                        if (parts.Length >= 2)
                            path = parts[1];

                        if (method == "OPTIONS")
                        {
                            SendPreflight(stream);
                        }
                        else if (path.StartsWith("/position"))
                        {
                            SendJson(stream);
                        }
                        else
                        {
                            SendDiagnosticPage(stream);
                        }
                    }
                }
            }
            catch (SocketException)
            {
                if (!serverRunning) break;
            }
            catch (Exception ex)
            {
                Plugin.Logger.LogWarning($"Live-position server request failed: {ex.Message}");
            }
        }
    }

    private static void UnityToBigWalk(float unityX, float unityZ, out float gameX, out float gameY)
    {
        // Calibrated from three in-game samples.
        // Big Walk's horizontal world axes are rotated ~45 degrees relative to Unity X/Z.
        const float InvSqrt2 = 0.70710678118f;

        gameX = (unityX + unityZ) * InvSqrt2 + 1900f;
        gameY = (unityX - unityZ) * InvSqrt2 + 3300f;
    }

    private void SendJson(NetworkStream stream)
    {
        float x, y, z;
        bool found;
        string name;

        lock (dataLock)
        {
            x = posX;
            y = posY;
            z = posZ;
            found = hasPlayer;
            name = objectName ?? "";
        }

        float gameX = 0f;
        float gameY = 0f;
        if (found)
            UnityToBigWalk(x, z, out gameX, out gameY);

        string safeName = name.Replace("\\", "\\\\").Replace("\"", "\\\"");
        string json =
            "{"
            + $"\"connected\":{(found ? "true" : "false")},"
            + $"\"object\":\"{safeName}\","
            + $"\"unityX\":{x.ToString(System.Globalization.CultureInfo.InvariantCulture)},"
            + $"\"unityY\":{y.ToString(System.Globalization.CultureInfo.InvariantCulture)},"
            + $"\"unityZ\":{z.ToString(System.Globalization.CultureInfo.InvariantCulture)},"
            + $"\"gameX\":{gameX.ToString(System.Globalization.CultureInfo.InvariantCulture)},"
            + $"\"gameY\":{gameY.ToString(System.Globalization.CultureInfo.InvariantCulture)}"
            + "}";

        SendResponse(stream, "application/json; charset=utf-8", json);
    }

    private void SendDiagnosticPage(NetworkStream stream)
    {
        const string html = @"<!doctype html>
<html>
<head>
<meta charset=""utf-8"">
<title>Big Walk Live Position</title>
<style>
body{font-family:system-ui;background:#101317;color:#eef2f6;margin:0;display:grid;place-items:center;min-height:100vh}
.card{background:#191e25;border:1px solid #303946;border-radius:14px;padding:26px;min-width:380px;box-shadow:0 12px 40px #0008}
h1{font-size:20px;margin:0 0 16px}
.status{font-size:13px;color:#aeb9c5;margin-bottom:16px}
.grid{display:grid;grid-template-columns:90px 1fr;gap:8px 18px;font-size:18px}
.v{font-family:ui-monospace,Consolas,monospace;font-weight:700}
.note{margin-top:18px;font-size:12px;color:#93a0ad;line-height:1.5}
</style>
</head>
<body>
<div class=""card"">
<h1>Big Walk Live Position — diagnostic</h1>
<div id=""status"" class=""status"">Connecting…</div>
<div class=""grid"">
<div>Game Y</div><div id=""gy"" class=""v"">—</div>
<div>Game X</div><div id=""gx"" class=""v"">—</div>
<div>Unity X</div><div id=""x"" class=""v"">—</div>
<div>Altitude</div><div id=""y"" class=""v"">—</div>
<div>Unity Z</div><div id=""z"" class=""v"">—</div>
<div>Object</div><div id=""obj"" class=""v"" style=""font-size:13px"">—</div>
</div>
<div class=""note"">
Game Y/X is now calculated from the calibrated Unity X/Z transform.
Unity Y is shown separately as altitude.
</div>
</div>
<script>
async function tick(){
  try{
    const r=await fetch('/position',{cache:'no-store'});
    const d=await r.json();
    document.getElementById('status').textContent=d.connected?'PLAYER FOUND':'Waiting for PlayerCharacter…';
    document.getElementById('gy').textContent=d.connected?Number(d.gameY).toFixed(1):'—';
    document.getElementById('gx').textContent=d.connected?Number(d.gameX).toFixed(1):'—';
    document.getElementById('x').textContent=Number(d.unityX).toFixed(3);
    document.getElementById('y').textContent=Number(d.unityY).toFixed(3);
    document.getElementById('z').textContent=Number(d.unityZ).toFixed(3);
    document.getElementById('obj').textContent=d.object||'—';
  }catch(e){
    document.getElementById('status').textContent='Bridge unavailable';
  }
}
setInterval(tick,250);tick();
</script>
</body>
</html>";

        SendResponse(stream, "text/html; charset=utf-8", html);
    }

    private void SendPreflight(NetworkStream stream)
    {
        string headers =
            "HTTP/1.1 204 No Content\r\n"
            + "Access-Control-Allow-Origin: *\r\n"
            + "Access-Control-Allow-Methods: GET, OPTIONS\r\n"
            + "Access-Control-Allow-Headers: Content-Type\r\n"
            + "Access-Control-Allow-Private-Network: true\r\n"
            + "Access-Control-Max-Age: 600\r\n"
            + "Cache-Control: no-store\r\n"
            + "Connection: close\r\n"
            + "Content-Length: 0\r\n"
            + "\r\n";

        byte[] headerBytes = Encoding.ASCII.GetBytes(headers);
        stream.Write(headerBytes, 0, headerBytes.Length);
        stream.Flush();
    }

    private void SendResponse(NetworkStream stream, string contentType, string body)
    {
        byte[] bodyBytes = Encoding.UTF8.GetBytes(body);
        string headers =
            "HTTP/1.1 200 OK\r\n"
            + $"Content-Type: {contentType}\r\n"
            + $"Content-Length: {bodyBytes.Length}\r\n"
            + "Access-Control-Allow-Origin: *\r\n"
            + "Access-Control-Allow-Methods: GET, OPTIONS\r\n"
            + "Access-Control-Allow-Headers: Content-Type\r\n"
            + "Access-Control-Allow-Private-Network: true\r\n"
            + "Cache-Control: no-store\r\n"
            + "Connection: close\r\n"
            + "\r\n";

        byte[] headerBytes = Encoding.ASCII.GetBytes(headers);
        stream.Write(headerBytes, 0, headerBytes.Length);
        stream.Write(bodyBytes, 0, bodyBytes.Length);
        stream.Flush();
    }

    public void OnDestroy()
    {
        serverRunning = false;

        try { listener?.Stop(); } catch { }

        try
        {
            if (serverThread != null && serverThread.IsAlive)
                serverThread.Join(500);
        }
        catch { }
    }
}
