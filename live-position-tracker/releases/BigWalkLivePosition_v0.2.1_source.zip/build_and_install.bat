@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "PROFILE="

REM 1) Optional command-line override:
REM    build_and_install.bat "C:\...\profiles\MyProfile"
if not "%~1"=="" set "PROFILE=%~1"

REM 2) Otherwise use the saved profile path.
if not defined PROFILE (
  if exist "%~dp0thunderstore_profile_path.txt" (
    set /p PROFILE=<"%~dp0thunderstore_profile_path.txt"
  )
)

REM 3) If we still do not have one, run the graphical configurator.
if not defined PROFILE (
  echo No Thunderstore profile has been configured yet.
  echo Opening the profile picker...
  call "%~dp0configure_profile.bat"
  if exist "%~dp0thunderstore_profile_path.txt" (
    set /p PROFILE=<"%~dp0thunderstore_profile_path.txt"
  )
)

if not defined PROFILE (
  echo.
  echo ERROR: No Thunderstore profile was selected.
  pause
  exit /b 1
)

echo.
echo Using Thunderstore profile:
echo   %PROFILE%
echo.

if not exist "%PROFILE%\BepInEx\core\BepInEx.Unity.IL2CPP.dll" (
  echo ERROR: BepInEx 6 IL2CPP was not found in this profile.
  echo.
  echo Expected:
  echo   %PROFILE%\BepInEx\core\BepInEx.Unity.IL2CPP.dll
  echo.
  echo Run configure_profile.bat to choose a different profile.
  pause
  exit /b 1
)

if not exist "%PROFILE%\BepInEx\interop\UnityEngine.CoreModule.dll" (
  echo ERROR: BepInEx interop files were not found in this profile.
  echo.
  echo Launch Big Walk MODDED through this Thunderstore profile once,
  echo close the game, then run this installer again.
  pause
  exit /b 1
)

where dotnet >nul 2>nul
if errorlevel 1 (
  echo ERROR: The .NET SDK was not found.
  echo Install the .NET 6 SDK, then try again.
  pause
  exit /b 1
)

echo Building plugin...
dotnet build BigWalkLivePosition.csproj -c Release -p:ProfilePath="%PROFILE%"
if errorlevel 1 (
  echo.
  echo BUILD FAILED.
  pause
  exit /b 1
)

set "DEST=%PROFILE%\BepInEx\plugins\BigWalkLivePosition"
if not exist "%DEST%" mkdir "%DEST%"

copy /Y "bin\Release\net6.0\BigWalkLivePosition.dll" "%DEST%\BigWalkLivePosition.dll" >nul
if errorlevel 1 (
  echo.
  echo ERROR: Build succeeded, but the DLL could not be copied.
  echo Destination:
  echo   %DEST%
  pause
  exit /b 1
)

echo.
echo SUCCESS.
echo Installed to your Thunderstore profile:
echo   %DEST%\BigWalkLivePosition.dll
echo.
echo Launch Big Walk with "Start modded" using THIS profile.
echo Then open:
echo   http://127.0.0.1:32145/
echo.
pause
